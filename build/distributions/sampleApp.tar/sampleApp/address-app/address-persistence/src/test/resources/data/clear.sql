truncate table targetaddress;
truncate table town;
truncate table address;
truncate table target;